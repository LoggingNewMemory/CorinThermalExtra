ui_print "-----------[ MODULE INFO ]-----------"
sleep 0.5
ui_print "Name : Corin Thermal Mods"
ui_print "Version : 2.0 "
ui_print "Support Device : Helio G99 series"
ui_print "Unofficial Support: MT 6833"
ui_print "Support Root : Magisk / KernelSU / APatch"
ui_print "Heavy Thanks to : @PersonPemula"
ui_print ""
sleep 1

ui_print "====================================="
ui_print "       Applying Thermal Mods         "
ui_print "====================================="

ui_print ""
sleep 1

ui_print "====================================="
ui_print "        Apply Thermal Mods OK        "
ui_print "====================================="

am start -a android.intent.action.VIEW -d https://t.me/yamadacookingcenter/52 >/dev/null 2>&1