resetprop -n ro.boottime.thermald 0
resetprop -n ro.boottime.vendor.thermal-hal-2-0.mtk 0
resetprop -n ro.vendor.mtk_thermal_2_0 0
resetprop -n ro.boottime.thermal_core 0